using UnityEditor;
using UnityEngine;

public class DespawnerX : MonoBehaviour
{
    
    [SerializeField]
    public float destroyX;

void Update()
{
    if (transform.position.x > destroyX)
    {
        Destroy(gameObject);
    }
}
void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("Triggered with: " + other.name);

        if (other.CompareTag("Bullet"))
        {
            Destroy(gameObject);
        }
    }

}
