using UnityEditor.Callbacks;
using UnityEngine;

public class EnemyVmove : MonoBehaviour
{
    public float startSpeedV = 0.5f;
    public float accelerationV = 0.05f;   // speed increase per second
    public float maxSpeedV = 5f;
    public float currentSpeedV;
    private Rigidbody2D rbv;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Awake()
    {
        currentSpeedV = startSpeedV;
        rbv=GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        currentSpeedV += accelerationV * Time.deltaTime;
        currentSpeedV = Mathf.Min(currentSpeedV, maxSpeedV);

        // Move enemy
        rbv.linearVelocity = new Vector2(0,-currentSpeedV);
    }
}
