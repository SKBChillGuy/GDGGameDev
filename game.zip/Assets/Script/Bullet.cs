// Source - https://stackoverflow.com/a
// Posted by Shoaib Wattoo
// Retrieved 2026-01-26, License - CC BY-SA 4.0

using UnityEngine;
public class Bullet : MonoBehaviour
{
    public float speed = 10f;
    [SerializeField] GameObject gun;
    [SerializeField] private float Min_y, Max_y, Min_x, Max_x;


    void Start()
    {
        Rigidbody2D rb = GetComponent<Rigidbody2D>();
        

        // Set the bullet's velocity.
        rb.linearVelocity = transform.right * speed;
    }
}
