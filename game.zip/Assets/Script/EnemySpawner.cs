using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    [SerializeField] private GameObject enemyPrefab;

    [Header("Spawn Time (seconds)")]
    [SerializeField] private float startMinSpawnTime = 2f;
    [SerializeField] private float startMaxSpawnTime = 4f;
    [SerializeField] private float minSpawnLimit = 0.5f;

    [Header("Difficulty Scaling")]
    [SerializeField] private float spawnAcceleration = 0.05f; // seconds per second

    [Header("Render Range")]
    [SerializeField] private float renderRangeX;
    [SerializeField] private float renderRangeY;

    private float currentMinSpawn;
    private float currentMaxSpawn;
    private float timeUntilSpawn;

    void Awake()
    {
        currentMinSpawn = startMinSpawnTime;
        currentMaxSpawn = startMaxSpawnTime;
        SetTimeUntilSpawn();
    }

    void Update()
    {
        // Increase difficulty over time
        currentMinSpawn = Mathf.Max(minSpawnLimit, currentMinSpawn - spawnAcceleration * Time.deltaTime);
        currentMaxSpawn = Mathf.Max(minSpawnLimit, currentMaxSpawn - spawnAcceleration * Time.deltaTime);

        timeUntilSpawn -= Time.deltaTime;

        if (timeUntilSpawn <= 0f)
        {
            SpawnEnemy();
            SetTimeUntilSpawn();
        }
    }

    void SpawnEnemy()
    {
        Vector3 spawnPos = transform.position;
        GameObject clone = Instantiate(enemyPrefab, spawnPos, Quaternion.identity);

        // Destroy if outside bounds
        if (Mathf.Abs(spawnPos.x) > renderRangeX || Mathf.Abs(spawnPos.y) > renderRangeY)
        {
            Destroy(clone);
        }
    }

    void SetTimeUntilSpawn()
    {
        timeUntilSpawn = Random.Range(currentMinSpawn, currentMaxSpawn);
    }
}
