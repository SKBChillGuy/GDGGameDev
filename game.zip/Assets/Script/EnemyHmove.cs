using UnityEditor.Callbacks;
using UnityEngine;

public class EnemyHmove : MonoBehaviour
{
    public float startSpeed = 0.5f;
    public float acceleration = 0.05f;   // speed increase per second
    public float maxSpeed = 5f;
    public float currentSpeed;
    private Rigidbody2D rb;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Awake()
    {
        currentSpeed = startSpeed;
        rb=GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        currentSpeed += acceleration * Time.deltaTime;
        currentSpeed = Mathf.Min(currentSpeed, maxSpeed);

        // Move enemy
        rb.linearVelocity = new Vector2(currentSpeed, 0);
    }
}
