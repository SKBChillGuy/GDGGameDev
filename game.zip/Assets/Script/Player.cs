using UnityEngine;
using UnityEngine.Rendering;

public class Player : MonoBehaviour
{
    public float speed = 5f;
    private Rigidbody2D rb2d;

    private float moveHorizontal;
    private float moveVertical;

    public float Health,MaxHealth;
    [SerializeField]
    private HealthBarUI healthBar;
    [SerializeField]
    GameObject gun,bullet;
    

    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
        healthBar.SetMaxHealth(MaxHealth);

    }

    void Update()
    {
        
        // Movement input
        moveHorizontal = Input.GetAxisRaw("Horizontal");
        moveVertical = Input.GetAxisRaw("Vertical");

        // Rotate player toward mouse
        Vector3 mousePosition = GetMouseWorldPosition();
        Vector3 direction = mousePosition - transform.position;

        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

        // 🔑 Apply rotation to PLAYER itself
        transform.rotation = Quaternion.Euler(0f, 0f, angle);
        if (Input.GetKeyDown("o"))
        {
            setHealth(-10f);
        }
        if (Input.GetKeyDown("m"))
        {
            setHealth(+10f);
        }
        shoot();
        if (Health <= 0)
        {
            Destroy(gameObject);
        }
    }

    void FixedUpdate()
    {
        rb2d.linearVelocity = new Vector2(
            moveHorizontal * speed,
            moveVertical * speed
        );
    }

    // -------- Mouse helper --------
    public static Vector3 GetMouseWorldPosition()
    {
        Vector3 worldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        worldPos.z = 0f;
        return worldPos;
    }
    public void setHealth(float healthChange)
    {
        Health+=healthChange;
        Health=Mathf.Clamp(Health,0,MaxHealth);

        healthBar.SetHealth(Health);
    }
    // Source - https://stackoverflow.com/a
// Posted by Shoaib Wattoo
// Retrieved 2026-01-28, License - CC BY-SA 4.0

    void shoot()
    {   
        if(Input.GetMouseButtonDown(0)){
        // Create a new bullet GameObject.
        Instantiate(
            bullet,
            gun.transform.position,
            gun.transform.rotation);
        }
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Enemy"))
        {
            Debug.Log("Dead");
            setHealth(-10f);
        }
    }

}
