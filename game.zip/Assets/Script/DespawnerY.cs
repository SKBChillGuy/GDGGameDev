using UnityEditor;
using UnityEngine;

public class DespawnerY : MonoBehaviour
{
    
    [SerializeField]
    public float destroyY;

void Update()
{
    if (transform.position.y < destroyY)
    {
        Destroy(gameObject);
    }
}
void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("Triggered with: " + other.name);

        if (other.CompareTag("Bullet"))
        {
            Destroy(gameObject);
        }
    }

}
